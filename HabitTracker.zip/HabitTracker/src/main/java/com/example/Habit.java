package com.example;

public class Habit {
    private final int id;
    private final int userId;
    private final String name;
    private final String description;

    public Habit(int id, int userId, String name, String description) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.description = description;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public String getName() { return name; }
    public String getDescription() { return description; }
}
