package com.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HabitService service = new HabitService();
        Scanner sc = new Scanner(System.in);

        int userId = 1;

        while (true) {
            System.out.println("\n=== Habit Tracker ===");
            System.out.println("1. Add Habit");
            System.out.println("2. View Habits");
            System.out.println("3. Mark Habit as Done");
            System.out.println("4. Show Habit Streak");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt(); sc.nextLine();

            switch (choice) {
                case 1: service.addHabit(userId); break;
                case 2: service.viewHabits(userId); break;
                case 3:
                    System.out.print("Enter Habit ID to mark as done: ");
                    int habitId = sc.nextInt(); sc.nextLine();
                    service.markHabitDone(habitId); break;
                case 4:
                    System.out.print("Enter Habit ID to show streak: ");
                    int hId = sc.nextInt(); sc.nextLine();
                    service.showStreak(hId); break;
                case 5:
                    System.out.println("Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
