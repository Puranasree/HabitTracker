package com.example;

import java.sql.*;
import java.util.Scanner;

public class HabitService {
    Connection conn = DBConnection.getConnection();
    Scanner sc = new Scanner(System.in);

    public void addHabit(int userId) {
        System.out.print("Habit Name: ");
        String name = sc.nextLine();
        System.out.print("Description: ");
        String desc = sc.nextLine();

        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO habits (user_id, name, description) VALUES (?, ?, ?)");
            stmt.setInt(1, userId);
            stmt.setString(2, name);
            stmt.setString(3, desc);
            stmt.executeUpdate();
            System.out.println("✅ Habit added!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewHabits(int userId) {
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "SELECT * FROM habits WHERE user_id = ?");
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Habit ID: " + rs.getInt("id") +
                        " | Name: " + rs.getString("name") +
                        " | Description: " + rs.getString("description"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void markHabitDone(int habitId) {
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO habit_logs (habit_id, log_date) VALUES (?, CURDATE())");
            stmt.setInt(1, habitId);
            stmt.executeUpdate();
            System.out.println("✅ Marked as done for today.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void showStreak(int habitId) {
        try {
            PreparedStatement stmt = conn.prepareStatement(
                    "SELECT COUNT(*) AS days FROM habit_logs WHERE habit_id = ?");
            stmt.setInt(1, habitId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("🔥 Total Days Done: " + rs.getInt("days"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
