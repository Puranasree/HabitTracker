package com.example;

import java.sql.Date;

public class HabitLog {
    private final int id;
    private final int habitId;
    private final Date logDate;

    public HabitLog(int id, int habitId, Date logDate) {
        this.id = id;
        this.habitId = habitId;
        this.logDate = logDate;
    }

    public int getId() { return id; }
    public int getHabitId() { return habitId; }
    public Date getLogDate() { return logDate; }
}
